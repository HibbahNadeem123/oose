﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LogIN;
using Account;

namespace OOSELAB5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            CreateAccount ca = new CreateAccount();
            ca.Show();
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
           if( LogIN.Class1.Verification(textBox1.Text, textBox2.Text)==true)
            {
                MessageBox.Show("Congratulation! You are logged in!");
            }
           else
            {
                MessageBox.Show("Wrong Username or password");
            }
        }
    }
}
